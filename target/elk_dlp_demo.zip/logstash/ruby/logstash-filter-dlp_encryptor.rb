require 'jar_dependencies'
require_jar('org.logstash.javaapi', 'logstash-filter-dlp_encryptor', '0.0.1')
