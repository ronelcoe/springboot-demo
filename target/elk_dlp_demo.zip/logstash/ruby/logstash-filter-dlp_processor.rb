require 'jar_dependencies'
require_jar('org.logstash.javaapi', 'logstash-filter-dlp_processor', '0.0.1')
