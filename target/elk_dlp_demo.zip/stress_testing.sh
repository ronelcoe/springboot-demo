#!/bin/bash

echo "Loading sentitive dummy data"
curl http://localhost:8080/dlp/load/_data_elk_sensitiveData

echo "Generating dummy logs for applications"
curl "http://localhost:8080/dlp/generateLog/_data_elk_applogs_dlp-cx-authentication.log$1" & curl "http://localhost:8080/dlp/generateLog/_data_elk_applogs_dlp-ebanking.log$1" & curl "http://localhost:8080/dlp/generateLog/_data_elk_applogs_dlp-tat.log$1"
exit 0
